telegram: @antmog

- Feel free to upgrade versions
- Change config/shared folder regarding your system

You will need to:
1) Config teamcity (add build, vcs, vcs trigger, build steps, setting.xml for maven)
example of settings.xml is included (w/o my passwords ofc)
2) After reading docker-compose.yml of teamcity+agent you will figure out where to put maven and mavenrepo(if you dont want to download),
if you want you still can use built-in maven
3) Name of mongo container used in demo app for integration tests


######################GUIDE####################
1) git clone https://github.com/antmog/docker-demo.git - this is my example. I dont think you have access to commit there (:
So you can create your own repository and own dockerhub (you can use your own registry if you want)
2) run "docker-compose up" with teamcity+agent after you edited it according to your needs
3) go to teamcity endpoint, go through steps (inbuild db is ok for our needs), add agent to teamcity
4) go go to docker-demo/mongo - execute scripts (create network, then run mongo)
5) after you added build steps and vcs link/trigger you can commit changes to repo
6) Teamcity will start build, i have 2 steps in teamcity:
							a) mvn clean install (jib plugin pushes image to docker hub)
							b) sh startApp.sh - pulls and restarts this image